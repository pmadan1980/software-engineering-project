class Bookmark < Sequel::Model
end