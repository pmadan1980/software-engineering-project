class Report < Sequel::Model

end