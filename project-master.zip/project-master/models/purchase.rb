class Purchase < Sequel::Model
  
end
