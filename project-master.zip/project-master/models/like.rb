class Like < Sequel::Model
end