# Gems
Before running the application, you must install all required gems using this command:
- `bundle install`

# How to Deploy
To run the application, run the command:
- `sinatra`

# Running Tests
To run tests, run the command whilst in the main directory (/project):
- `rspec`

# Login details
- usernames: reader, writer, staff
- passwords: same as username
- email: \<username>@email.com
